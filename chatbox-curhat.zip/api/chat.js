import { Configuration, OpenAIApi } from "openai";

const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(config);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { kategori, pesan } = req.body;

  const prompt = `
Kamu adalah seorang konselor sekolah yang empatik dan hangat. Jawablah curhatan siswa secara sopan, positif, dan mendukung. Jangan menghakimi. Topik curhat: ${kategori}. 
Curhatan siswa: "${pesan}"
Jawabanmu:
`;

  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 300,
      temperature: 0.7,
    });

    const balasan = completion.data.choices[0].message.content.trim();
    res.status(200).json({ balasan });
  } catch (e) {
    res.status(500).json({ error: "Gagal mendapatkan balasan dari AI." });
  }
}