async function kirim() {
  const kategori = document.getElementById("kategori").value;
  const input = document.getElementById("userInput");
  const pesan = input.value.trim();
  if (!pesan || !kategori) return;

  tampilkanPesan("🧑‍🎓 Kamu", pesan);

  input.value = "";

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ kategori, pesan }),
  });

  const data = await res.json();
  tampilkanPesan("🤖 Konselor AI", data.balasan);
}

function tampilkanPesan(pengirim, teks) {
  const chatLog = document.getElementById("chat-log");
  const div = document.createElement("div");
  div.innerHTML = `<strong>${pengirim}:</strong> ${teks}`;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}